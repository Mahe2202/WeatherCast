//
//  WeatherDetailsDataModel.swift
//  WeatherForecast
//
//  Created by Udhayakumar on 17/10/22.
//

import Foundation


// MARK: - DataModel Store data
 class APICallRepository {
    
    let apiClient: APIClient!
         
    init(apiClient: APIClient) {
        self.apiClient = apiClient
    }
    
     func getDetails(city: String, _ completion: @escaping ((Result<ResponseData>) -> Void)) {
        let resource = Resource(url: URL(string: "https://api.weatherapi.com/v1/forecast.json?key=522db6a157a748e2996212343221502&q=\(city)&days=7&aqi=no&alerts=no")!)
        apiClient.load(resource) { (result) in
            switch result {
            case .success(let data):
                do {
                    let items = try JSONDecoder().decode(ResponseData.self, from: data)
                    DispatchQueue.main.async {
                    completion(.success(items))
                    }
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
}





// MARK: - Model Data....

struct ResponseData : Codable {

    let location : LocationDetails?
    let forecast : Forecast?


    enum CodingKeys: String, CodingKey {
        case location = "location"
        case forecast = "forecast"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        location = try values.decodeIfPresent(LocationDetails.self, forKey: .location)
        forecast = try values.decodeIfPresent(Forecast.self, forKey: .forecast)
    }


}

struct LocationDetails : Codable {

    let country : String?
        let lat : Float?
        let localtime : String?
        let localtimeEpoch : Int?
        let lon : Float?
        let name : String?
        let region : String?
        let tzId : String?


        enum CodingKeys: String, CodingKey {
            case country = "country"
            case lat = "lat"
            case localtime = "localtime"
            case localtimeEpoch = "localtime_epoch"
            case lon = "lon"
            case name = "name"
            case region = "region"
            case tzId = "tz_id"
        }
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            country = try values.decodeIfPresent(String.self, forKey: .country)
            lat = try values.decodeIfPresent(Float.self, forKey: .lat)
            localtime = try values.decodeIfPresent(String.self, forKey: .localtime)
            localtimeEpoch = try values.decodeIfPresent(Int.self, forKey: .localtimeEpoch)
            lon = try values.decodeIfPresent(Float.self, forKey: .lon)
            name = try values.decodeIfPresent(String.self, forKey: .name)
            region = try values.decodeIfPresent(String.self, forKey: .region)
            tzId = try values.decodeIfPresent(String.self, forKey: .tzId)
        }


}


struct Forecast : Codable {

    let forecastday : [Forecastday]?


    enum CodingKeys: String, CodingKey {
        case forecastday = "forecastday"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        forecastday = try values.decodeIfPresent([Forecastday].self, forKey: .forecastday)
    }


}
struct Forecastday : Codable {

    let date : String?
    let dateEpoch : Int?
    let day : Day?

    enum CodingKeys: String, CodingKey {
        case date = "date"
        case dateEpoch = "date_epoch"
        case day = "day"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        date = try values.decodeIfPresent(String.self, forKey: .date)
        dateEpoch = try values.decodeIfPresent(Int.self, forKey: .dateEpoch)
        day = try values.decodeIfPresent(Day.self, forKey: .day)
    
    }


}


struct Day : Codable {

    let dailyChanceOfRain : Int?
    let dailyChanceOfSnow : Int?
    let dailyWillItRain : Int?
    let dailyWillItSnow : Int?
    let maxtempC : Float?
    let maxtempF : Float?
    let maxwindKph : Float?
    let maxwindMph : Float?
    let mintempC : Float?
    let mintempF : Float?



    enum CodingKeys: String, CodingKey {
        case dailyChanceOfRain = "daily_chance_of_rain"
        case dailyChanceOfSnow = "daily_chance_of_snow"
        case dailyWillItRain = "daily_will_it_rain"
        case dailyWillItSnow = "daily_will_it_snow"
        case maxtempC = "maxtemp_c"
        case maxtempF = "maxtemp_f"
        case maxwindKph = "maxwind_kph"
        case maxwindMph = "maxwind_mph"
        case mintempC = "mintemp_c"
        case mintempF = "mintemp_f"

    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        dailyChanceOfRain = try values.decodeIfPresent(Int.self, forKey: .dailyChanceOfRain)
        dailyChanceOfSnow = try values.decodeIfPresent(Int.self, forKey: .dailyChanceOfSnow)
        dailyWillItRain = try values.decodeIfPresent(Int.self, forKey: .dailyWillItRain)
        dailyWillItSnow = try values.decodeIfPresent(Int.self, forKey: .dailyWillItSnow)
        maxtempC = try values.decodeIfPresent(Float.self, forKey: .maxtempC)
        maxtempF = try values.decodeIfPresent(Float.self, forKey: .maxtempF)
        maxwindKph = try values.decodeIfPresent(Float.self, forKey: .maxwindKph)
        maxwindMph = try values.decodeIfPresent(Float.self, forKey: .maxwindMph)
        mintempC = try values.decodeIfPresent(Float.self, forKey: .mintempC)
        mintempF = try values.decodeIfPresent(Float.self, forKey: .mintempF)
    }


}
