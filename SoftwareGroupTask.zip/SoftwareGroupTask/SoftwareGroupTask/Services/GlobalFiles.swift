//
//  GlobalFiles.swift
//  SoftwareGroupTask
//
//  Created by Udhayakumar on 17/10/22.
//

import Foundation

// MARK: - Convert Date
    public func convertDateFormat(inputDate: String) -> String {

         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "yyyy-MM-dd"

         let date = dateFormatter.date(from: inputDate)

         let convertDateFormatter = DateFormatter()
         convertDateFormatter.dateFormat = "EEE"

         return convertDateFormatter.string(from: date!)
      }
    
