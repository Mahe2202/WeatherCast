//
//  ViewController.swift
//  SoftwareGroupTask
//
//  Created by Udhayakumar on 17/10/22.
//

import UIKit
import CoreLocation

class ViewController: UIViewController  {

    @IBOutlet weak var countryLbl: UILabel!
    @IBOutlet weak var stateLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    
    
    @IBOutlet weak var topLabel1: UILabel!
    @IBOutlet weak var topLabel2: UILabel!
    @IBOutlet weak var topLabel3: UILabel!
    @IBOutlet weak var topLabel4: UILabel!
    @IBOutlet weak var topLabel5: UILabel!
    
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView5: UIImageView!
    
    @IBOutlet weak var bottomLabel1: UILabel!
    @IBOutlet weak var bottomLabel2: UILabel!
    @IBOutlet weak var bottomLabel3: UILabel!
    @IBOutlet weak var bottomLabel4: UILabel!
    @IBOutlet weak var bottomLabel5: UILabel!
    

    
    var dataModel = APICallRepository(apiClient: APIClient())
    
    var city = ""
    var locationManger: CLLocationManager!
    var currentlocation: CLLocation?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        getLocation()
    }
    
    
    
    // MARK: - // MARK: - Update UI Session 1
    func UIDataUpdates() {
        self.dataModel.getDetails(city: self.city) { (result) in
            switch  result {
            case .success(let details):
                if let location = details.location {
                self.countryLbl.text = location.country
                    self.stateLbl.text = location.region
                    self.cityLbl.text = location.name
                    self.dateLbl.text = location.localtime
                    if let forecast = details.forecast, let forecastDays = forecast.forecastday, forecastDays.count > 0 {
                          self.updateDays(daily: forecastDays)
                    }
                }
            case .failure(let error):
                print(error)
            
            }
        }
    
    }
    
    // MARK: - Update UI Session 2
    func updateDays(daily: [Forecastday]) {
        let topLabels = [topLabel1, topLabel2, topLabel3, topLabel4, topLabel5], bottomLabels = [bottomLabel1, bottomLabel2, bottomLabel3, bottomLabel4, bottomLabel5]
        for i in 0..<daily.count {
            let days = daily[i]
            let weatherTemperature = days.day?.maxtempC
            topLabels[i]?.text = convertDateFormat(inputDate: days.date!)
            bottomLabels[i]?.text = "\(Int(weatherTemperature!.rounded()))°C"
        }
    }
    
}


extension ViewController: CLLocationManagerDelegate {
    
    
    func getLocation() {
       
        if (CLLocationManager.locationServicesEnabled()) {
            locationManger = CLLocationManager()
            locationManger.delegate = self
            locationManger.desiredAccuracy = kCLLocationAccuracyBest
            locationManger.requestAlwaysAuthorization()
            locationManger.startUpdatingLocation()
        }
        
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            self.currentlocation = location
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                if let error = error {
                    debugPrint(error.localizedDescription)
                }
                if let placemarks = placemarks {
                    if placemarks.count > 0 {
                        let placemark = placemarks[0]
                        if let city = placemark.locality {
                        self.city = city
                        }
                    }
                }
            }
            
            UIDataUpdates()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        debugPrint(error.localizedDescription)
    }
    
}
